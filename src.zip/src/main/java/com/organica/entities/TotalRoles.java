package com.organica.entities;

public enum TotalRoles {
    ADMIN,
    USER

}
